package week2.day1;

public class CreateLead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
